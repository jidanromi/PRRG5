<?php
include 'db_connect.php'; // Hubungkan ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_buku = $_POST["nama_buku"];
    $id_vendor = $_POST["id_vendor"];
    $id_jenis_buku = $_POST["id_jenis_buku"];
    $jml_stock = $_POST["jml_stock"];

    // Query SQL untuk menambahkan data ke tabel buku
    $sql = "INSERT INTO buku (nama_buku, id_vendor, id_jenis_buku, jml_stock) VALUES (:nama_buku, :id_vendor, :id_jenis_buku, :jml_stock)";
    $stmt = $pdo->prepare($sql);

    // Bind parameter
    $stmt->bindParam(":nama_buku", $nama_buku);
    $stmt->bindParam(":id_vendor", $id_vendor);
    $stmt->bindParam(":id_jenis_buku", $id_jenis_buku);
    $stmt->bindParam(":jml_stock", $jml_stock);

    // Eksekusi statement SQL
    if ($stmt->execute()) {
        header("Location: read_buku.php"); // Redirect ke halaman Read setelah data berhasil ditambahkan
        exit();
    } else {
        echo "Gagal menambahkan data.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tambah Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #008080;
            padding: 20px;
            text-align: center;
        }

        form {
            background-color: white;
            border: 1px solid #ddd;
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #008080;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #005555;
        }

        a {
            text-decoration: none;
            background-color: #008080;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }

        a:hover {
            background-color: #005555;
        }
    </style>
</head>
<body>
    <h1>Tambah Buku</h1>
    <form method="POST" action="">
        <label for="nama_buku">Nama Buku:</label>
        <input type="text" id="nama_buku" name="nama_buku" required><br><br>

        <label for="id_vendor">Vendor:</label>
        <select id="id_vendor" name="id_vendor" required>
            <?php
            // Query SQL untuk mengambil data dari tabel Vendor
            $sql_vendor = "SELECT id_vendor, nama_vendor FROM vendor";
            $stmt_vendor = $pdo->query($sql_vendor);

            // Loop untuk menampilkan data Vendor dalam dropdown
            while ($row_vendor = $stmt_vendor->fetch(PDO::FETCH_ASSOC)) {
                echo '<option value="' . $row_vendor["id_vendor"] . '">' . $row_vendor["nama_vendor"] . '</option>';
            }
            ?>
        </select><br><br>

        <label for="id_jenis_buku">Jenis Buku:</label>
        <select id="id_jenis_buku" name="id_jenis_buku" required>
            <?php
            // Query SQL untuk mengambil data dari tabel Jenis Buku
            $sql_jenis_buku = "SELECT id_jenis_buku, nama_jenis_buku FROM jenisbuku";
            $stmt_jenis_buku = $pdo->query($sql_jenis_buku);

            // Loop untuk menampilkan data Jenis Buku dalam dropdown
            while ($row_jenis_buku = $stmt_jenis_buku->fetch(PDO::FETCH_ASSOC)) {
                echo '<option value="' . $row_jenis_buku["id_jenis_buku"] . '">' . $row_jenis_buku["nama_jenis_buku"] . '</option>';
            }
            ?>
        </select><br><br>

        <label for="jml_stock">Jumlah Stok:</label>
        <input type="text" id="jml_stock" name="jml_stock" required><br><br>

        <input type="submit" value="Tambah Buku">
    </form>
    <a href="read_buku.php">Kembali ke Daftar Buku</a>
</body>
</html>