<?php
include 'db_connect.php'; // Hubungkan ke database

// Query SQL untuk mengambil semua data dari tabel buku
$sql = "SELECT * FROM buku";
$stmt = $pdo->query($sql);
$buku_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!-- Tampilan Daftar Buku -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Daftar Buku</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        h1 {
            color: #008080;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #008080;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            background-color: #008080;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        a:hover {
            background-color: #005555;
        }
    </style>
</head>
<body>
    <h1>Daftar Buku</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID Buku</th>
                <th>Nama Buku</th>
                <th>ID Vendor</th>
                <th>ID Jenis Buku</th>
                <th>Jumlah Stok</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($buku_list as $buku): ?>
                <tr>
                    <td><?= $buku['id_buku'] ?></td>
                    <td><?= $buku['nama_buku'] ?></td>
                    <td><?= $buku['id_vendor'] ?></td>
                    <td><?= $buku['id_jenis_buku'] ?></td>
                    <td><?= $buku['jml_stock'] ?></td>
                    <td>
                        <a href="update_buku.php?id=<?= $buku['id_buku'] ?>">Edit</a>
                        <a href="delete_buku.php?id=<?= $buku['id_buku'] ?>">Hapus</a>
                        <a href="export_pdf.php" class="btn-export-pdf">Export to PDF</a>
                        <a href="index.php">Kembali ke Halaman Utama</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="create_buku.php">Tambah Buku Baru</a>
</body>
</html>
