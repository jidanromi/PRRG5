<?php
require('fpdf.php'); // Memasukkan library FPDF

// Kode untuk mengambil data dari database (sesuaikan dengan struktur tabel Anda)
include 'db_connect.php';
$sql = "SELECT * FROM buku";
$stmt = $pdo->query($sql);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Membuat objek PDF
$pdf = new FPDF();
$pdf->AddPage();

// Mengatur font
$pdf->SetFont('Arial', 'B', 12);

// Header tabel
$pdf->Cell(40, 10, 'ID Buku', 1);
$pdf->Cell(60, 10, 'Nama Buku', 1);
$pdf->Cell(40, 10, 'ID Vendor', 1);
$pdf->Cell(40, 10, 'ID Jenis Buku', 1);
$pdf->Cell(30, 10, 'Jumlah Stok', 1);
$pdf->Ln();

// Menampilkan data dari database
foreach ($data as $row) {
    $pdf->Cell(40, 10, $row['id_buku'], 1);
    $pdf->Cell(60, 10, $row['nama_buku'], 1);
    $pdf->Cell(40, 10, $row['id_vendor'], 1);
    $pdf->Cell(40, 10, $row['id_jenis_buku'], 1);
    $pdf->Cell(30, 10, $row['jml_stock'], 1);
    $pdf->Ln();
}

// Output PDF
$pdf->Output();
?>
