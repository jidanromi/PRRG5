<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_jenis_buku = $_POST["nama_jenis_buku"];
    
    $sql = "INSERT INTO jenisbuku (nama_jenis_buku) VALUES (:nama_jenis_buku)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":nama_jenis_buku", $nama_jenis_buku);

    if ($stmt->execute()) {
        header("Location: read_jenisbuku.php");
        exit();
    } else {
        echo "Gagal menambahkan data jenis buku.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tambah Jenis Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #008080;
            padding: 20px;
            text-align: center;
        }

        form {
            background-color: white;
            border: 1px solid #ddd;
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #008080;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #005555;
        }

        a {
            text-decoration: none;
            background-color: #008080;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }

        a:hover {
            background-color: #005555;
        }
    </style>
</head>
<body>
    <h1>Tambah Jenis Buku</h1>
    <form method="POST" action="">
        <label for="nama_jenis_buku">Nama Jenis Buku:</label>
        <input type="text" id="nama_jenis_buku" name="nama_jenis_buku" required><br><br>

        <input type="submit" value="Tambah Jenis Buku">
    </form>
    <a href="read_jenisbuku.php">Kembali ke Daftar Jenis Buku</a>
</body>
</html>
