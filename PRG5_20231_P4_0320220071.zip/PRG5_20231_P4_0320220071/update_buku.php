<?php
include 'db_connect.php'; // Hubungkan ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $id_buku = $_POST["id_buku"];
    $nama_buku = $_POST["nama_buku"];
    $id_vendor = $_POST["id_vendor"];
    $id_jenis_buku = $_POST["id_jenis_buku"];
    $jml_stock = $_POST["jml_stock"];

    // Query SQL untuk mengupdate data buku
    $sql = "UPDATE buku SET nama_buku = :nama_buku, id_vendor = :id_vendor, id_jenis_buku = :id_jenis_buku, jml_stock = :jml_stock WHERE id_buku = :id_buku";
    $stmt = $pdo->prepare($sql);

        // Bind parameter
        $stmt->bindParam(":id_buku", $id_buku);
        $stmt->bindParam(":nama_buku", $nama_buku);
        $stmt->bindParam(":id_vendor", $id_vendor);
        $stmt->bindParam(":id_jenis_buku", $id_jenis_buku);
        $stmt->bindParam(":jml_stock", $jml_stock);
    
        // Eksekusi statement SQL
        if ($stmt->execute()) {
            header("Location: read_buku.php"); // Redirect ke halaman Read setelah data berhasil diupdate
            exit();
        } else {
            echo "Gagal mengupdate data.";
        }
    }
    
    // Ambil ID buku dari parameter URL
    $id_buku = $_GET["id"];
    
    // Query SQL untuk mengambil data buku berdasarkan ID
    $sql = "SELECT * FROM buku WHERE id_buku = :id_buku";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id_buku", $id_buku);
    $stmt->execute();
    $buku = $stmt->fetch(PDO::FETCH_ASSOC);
?>
    
    <!-- Tampilan Form Edit Buku -->
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Edit Buku</title>
    </head>
    <body>
        <h1>Edit Buku</h1>
        <form method="POST" action="">
            <input type="hidden" name="id_buku" value="<?= $buku['id_buku'] ?>">
            
            <label for="nama_buku">Nama Buku:</label>
            <input type="text" id="nama_buku" name="nama_buku" value="<?= $buku['nama_buku'] ?>" required><br><br>
    
            <label for="id_vendor">ID Vendor:</label>
            <input type="text" id="id_vendor" name="id_vendor" value="<?= $buku['id_vendor'] ?>" required><br><br>
    
            <label for="id_jenis_buku">ID Jenis Buku:</label>
            <input type="text" id="id_jenis_buku" name="id_jenis_buku" value="<?= $buku['id_jenis_buku'] ?>" required><br><br>
    
            <label for="jml_stock">Jumlah Stok:</label>
            <input type="text" id="jml_stock" name="jml_stock" value="<?= $buku['jml_stock'] ?>" required><br><br>
    
            <input type="submit" value="Simpan Perubahan">
        </form>
        <a href="read_buku.php">Kembali ke Daftar Buku</a>
    </body>
    </html>
    

