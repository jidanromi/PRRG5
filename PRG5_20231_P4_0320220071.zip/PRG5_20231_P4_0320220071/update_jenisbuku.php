<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id'])) {
    $id_jenis_buku = $_GET['id'];
    $nama_jenis_buku = $_POST["nama_jenis_buku"];
    
    $sql = "UPDATE jenisbuku SET nama_jenis_buku = :nama_jenis_buku WHERE id_jenis_buku = :id_jenis_buku";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id_jenis_buku", $id_jenis_buku);
    $stmt->bindParam(":nama_jenis_buku", $nama_jenis_buku);

    if ($stmt->execute()) {
        header("Location: read_jenisbuku.php");
        exit();
    } else {
        echo "Gagal mengubah data jenis buku.";
    }
}

if (isset($_GET['id'])) {
    $id_jenis_buku = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM jenisbuku WHERE id_jenis_buku = :id_jenis_buku");
    $stmt->bindParam(":id_jenis_buku", $id_jenis_buku);
    $stmt->execute();
    $jenis = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Jenis Buku</title>
</head>
<body>
    <h1>Edit Jenis Buku</h1>
    <form method="POST" action="">
        <label for="nama_jenis_buku">Nama Jenis Buku:</label>
        <input type="text" id="nama_jenis_buku" name="nama_jenis_buku" value="<?=$jenis['nama_jenis_buku']?>" required><br><br>

        <input type="submit" value="Simpan Perubahan">
    </form>
    <a href="read_jenisbuku.php">Kembali ke Daftar Jenis Buku</a>
</body>
</html>
