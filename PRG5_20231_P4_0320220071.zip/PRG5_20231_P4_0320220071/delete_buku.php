<?php
    include 'db_connect.php'; // Hubungkan ke database

    // Ambil ID buku yang ingin dihapus dari parameter URL
    $id_buku = $_GET["id"];
    
    // Hapus data buku berdasarkan ID
    $sql = "DELETE FROM buku WHERE id_buku = :id_buku";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id_buku", $id_buku);
    
    // Eksekusi statement SQL
    if ($stmt->execute()) {
        // Ambil seluruh data buku yang tersisa dalam tabel
        $sql_select = "SELECT * FROM buku";
        $stmt_select = $pdo->query($sql_select);
        $remaining_data = $stmt_select->fetchAll(PDO::FETCH_ASSOC);
    
        // Hapus seluruh data dalam tabel
        $sql_delete_all = "DELETE FROM buku";
        $stmt_delete_all = $pdo->prepare($sql_delete_all);
        $stmt_delete_all->execute();
    
        // Setel ulang nomor ID dengan auto increment ke 1
        $sql_reset_auto_increment = "ALTER TABLE buku AUTO_INCREMENT = 1";
        $stmt_reset_auto_increment = $pdo->prepare($sql_reset_auto_increment);
        $stmt_reset_auto_increment->execute();
    
        // Masukkan kembali data yang tersisa
        foreach ($remaining_data as $data) {
            $nama_buku = $data["nama_buku"];
            $id_vendor = $data["id_vendor"];
            $id_jenis_buku = $data["id_jenis_buku"];
            $jml_stock = $data["jml_stock"];
    
            // Query SQL untuk menambahkan data ke tabel buku dengan nomor ID otomatis
            $sql_insert = "INSERT INTO buku (nama_buku, id_vendor, id_jenis_buku, jml_stock) VALUES (:nama_buku, :id_vendor, :id_jenis_buku, :jml_stock)";
            $stmt_insert = $pdo->prepare($sql_insert);
            $stmt_insert->bindParam(":nama_buku", $nama_buku);
            $stmt_insert->bindParam(":id_vendor", $id_vendor);
            $stmt_insert->bindParam(":id_jenis_buku", $id_jenis_buku);
            $stmt_insert->bindParam(":jml_stock", $jml_stock);
            $stmt_insert->execute();
        }
    
        header("Location: read_buku.php"); // Redirect ke halaman Read setelah data berhasil dihapus dan nomor ID diatur ulang
        exit();
    } else {
        echo "Gagal menghapus data.";
    }    
?>
