<?php 
require 'vendor/autoload.php';

// Koneksi php dan mysql
$koneksi = mysqli_connect("localhost", "root", "", "mahasiswa");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Sheet pertama
$sheet->setTitle('Sheet 1');
$sheet->setCellValue('A1', 'No');
$sheet->setCellValue('B1', 'NIM');
$sheet->setCellValue('C1', 'Nama');
$sheet->setCellValue('D1', 'Prodi');

// Membaca data dari MySQL
$mahasiswa = mysqli_query($koneksi, "SELECT * FROM mahasiswa");
$row = 2;
$no = 1;

while ($record = mysqli_fetch_array($mahasiswa)) {
    $sheet->setCellValue('A' . $row, $no);
    $sheet->setCellValue('B' . $row, $record['nim']);
    $sheet->setCellValue('C' . $row, $record['nama']);
    $sheet->setCellValue('D' . $row, $record['prodi']);
    $row++;
    $no++;
}

$writer = new Xlsx($spreadsheet);

ob_clean();
$filename = 'Percobaan_ExportExcel2_71.xlsx';
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=\"$filename\"");
$writer->save("php://output");
?>
