<?php 
    require 'vendor/autoload.php';

    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

    $spreedsheet = new Spreadsheet();
    $sheet = $spreedsheet->getActiveSheet();
    $sheet->setCellValue('A1', 'HELLO WORLD!');

    $writer = new Xlsx($spreedsheet);

    //uncomment for save file on server
    //$writer->save('hello world.xlsx');

    ob_clean();
    $filename = 'Percobaan_ExportExcel_71.xlsx';
    header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheet.sheet");
    header("Content-Disposition: attachment;filename=\"$filename\"");
    $writer->save("php://output");
?>