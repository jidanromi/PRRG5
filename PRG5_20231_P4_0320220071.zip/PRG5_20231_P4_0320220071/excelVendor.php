<?php
    require 'PHPSPREADSHEET/vendor/autoload.php';

    $koneksi = mysqli_connect("localhost", "root","","perpustakaan_2023");

    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    $sheet->setTitle('Sheet 1');
    $sheet->setCellValue('A1','No');
    $sheet->setCellValue('B1','Id Vendor');
    $sheet->setCellValue('C1','Nama Vendor');
    $sheet->setCellValue('D1','Alamat Vendor');
    $sheet->setCellValue('E1','Telepon');
    $sheet->setCellValue('F1','Email');
    

    $JenisBuku = mysqli_query($koneksi,"select * from vendor");
    $row=2;
    $no=1;

    while($record = mysqli_fetch_array($JenisBuku)){
        $sheet->setCellValue('A'.$row,$no);
        $sheet->setCellValue('B'.$row,$record['id_vendor']);
        $sheet->setCellValue('C'.$row,$record['nama_vendor']);
        $sheet->setCellValue('D'.$row,$record['alamat_vendor']);
        $sheet->setCellValue('E'.$row,$record['telp_vendor']);
        $sheet->setCellValue('F'.$row,$record['email_vendor']);
        $row++;
        $no++;
    }

    $writer = new Xlsx($spreadsheet);

    ob_clean();
    $filename = 'Vendor.xlsx';
    header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheet.sheet");
    header("Content-Disposition: attachment;filename=\"$filename\"");
    $writer->save("php://output");

?>



