<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id_jenis_buku = $_GET['id'];

    // Hapus data jenis buku berdasarkan ID
    $stmt = $pdo->prepare("DELETE FROM jenisbuku WHERE id_jenis_buku = :id_jenis_buku");
    $stmt->bindParam(":id_jenis_buku", $id_jenis_buku);
    
    // Eksekusi statement SQL
    if ($stmt->execute()) {
        // Ambil seluruh data jenis buku yang tersisa dalam tabel
        $sql_select = "SELECT * FROM jenisbuku";
        $stmt_select = $pdo->query($sql_select);
        $remaining_data = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

        // Hapus seluruh data dalam tabel
        $sql_delete_all = "DELETE FROM jenisbuku";
        $stmt_delete_all = $pdo->prepare($sql_delete_all);
        $stmt_delete_all->execute();

        // Setel ulang nomor ID dengan auto increment ke 1
        $sql_reset_auto_increment = "ALTER TABLE jenisbuku AUTO_INCREMENT = 1";
        $stmt_reset_auto_increment = $pdo->prepare($sql_reset_auto_increment);
        $stmt_reset_auto_increment->execute();

        // Masukkan kembali data yang tersisa
        foreach ($remaining_data as $data) {
            $nama_jenis_buku = $data["nama_jenis_buku"];

            // Query SQL untuk menambahkan data jenis buku dengan nomor ID otomatis
            $sql_insert = "INSERT INTO jenisbuku (nama_jenis_buku) VALUES (:nama_jenis_buku)";
            $stmt_insert = $pdo->prepare($sql_insert);
            $stmt_insert->bindParam(":nama_jenis_buku", $nama_jenis_buku);
            $stmt_insert->execute();
        }

        header("Location: read_jenisbuku.php"); // Redirect ke halaman Read jenis buku setelah data berhasil dihapus dan nomor ID diatur ulang
        exit();
    } else {
        echo "Gagal menghapus data jenis buku.";
    }
}
?>
