<?php
    require 'PHPSPREADSHEET/vendor/autoload.php';

    $koneksi = mysqli_connect("localhost", "root","","perpustakaan_2023");

    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    $sheet->setTitle('Sheet 1');
    $sheet->setCellValue('A1','No');
    $sheet->setCellValue('B1','Id Jenis Buku');
    $sheet->setCellValue('C1','Nama Jenis Buku');
    

    $JenisBuku = mysqli_query($koneksi,"select * from jenisbuku");
    $row=2;
    $no=1;

    while($record = mysqli_fetch_array($JenisBuku)){
        $sheet->setCellValue('A'.$row,$no);
        $sheet->setCellValue('B'.$row,$record['id_jenis_buku']);
        $sheet->setCellValue('C'.$row,$record['nama_jenis_buku']);
        $row++;
        $no++;
    }

    $writer = new Xlsx($spreadsheet);

    ob_clean();
    $filename = 'Jenis_Buku.xlsx';
    header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheet.sheet");
    header("Content-Disposition: attachment;filename=\"$filename\"");
    $writer->save("php://output");

?>



