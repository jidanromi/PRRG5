<?php
include 'db_connect.php'; // Hubungkan ke database

// Ambil ID buku dari parameter URL
$id_buku = $_GET["id"];

// Query SQL untuk menghapus data buku berdasarkan ID
$sql = "DELETE FROM buku WHERE id_buku = :id_buku";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":id_buku", $id_buku);

// Eksekusi statement SQL
if ($stmt->execute()) {
    header("Location: read_buku.php"); // Redirect ke halaman Read setelah data berhasil dihapus
    exit();
} else {
    echo "Gagal menghapus data.";
}
?>
