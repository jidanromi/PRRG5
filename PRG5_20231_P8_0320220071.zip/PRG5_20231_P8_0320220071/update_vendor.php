<?php
include 'db_connect.php'; // Hubungkan ke database

// Ambil ID vendor dari parameter URL
$id_vendor = $_GET["id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_vendor = $_POST["nama_vendor"];
    $alamat_vendor = $_POST["alamat_vendor"];
    $telp_vendor = $_POST["telp_vendor"];
    $email_vendor = $_POST["email_vendor"];

    // Query SQL untuk mengupdate data di tabel vendor
    $sql = "UPDATE vendor SET nama_vendor = :nama_vendor, alamat_vendor = :alamat_vendor, telp_vendor = :telp_vendor, email_vendor = :email_vendor WHERE id_vendor = :id_vendor";
    $stmt = $pdo->prepare($sql);

    // Bind parameter
    $stmt->bindParam(":nama_vendor", $nama_vendor);
    $stmt->bindParam(":alamat_vendor", $alamat_vendor);
    $stmt->bindParam(":telp_vendor", $telp_vendor);
    $stmt->bindParam(":email_vendor", $email_vendor);
    $stmt->bindParam(":id_vendor", $id_vendor);

    // Eksekusi statement SQL
    if ($stmt->execute()) {
        header("Location: read_vendor.php"); // Redirect ke halaman Read setelah data berhasil diupdate
        exit();
    } else {
        echo "Gagal mengupdate data.";
    }
}

// Query SQL untuk mendapatkan data vendor berdasarkan ID
$sql = "SELECT * FROM vendor WHERE id_vendor = :id_vendor";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":id_vendor", $id_vendor);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Vendor</title>
</head>
<body>
    <h1>Edit Vendor</h1>
    <form method="POST" action="">
        <label for="nama_vendor">Nama Vendor:</label>
        <input type="text" id="nama_vendor" name="nama_vendor" value="<?php echo $row["nama_vendor"]; ?>" required><br><br>

        <label for="alamat_vendor">Alamat Vendor:</label>
        <input type="text" id="alamat_vendor" name="alamat_vendor" value="<?php echo $row["alamat_vendor"]; ?>" required><br><br>

        <label for="telp_vendor">No. Telp Vendor:</label>
        <input type="text" id="telp_vendor" name="telp_vendor" value="<?php echo $row["telp_vendor"]; ?>" required><br><br>

        <label for="email_vendor">Email Vendor:</label>
        <input type="text" id="email_vendor" name="email_vendor" value="<?php echo $row["email_vendor"]; ?>" required><br><br>

<input type="submit" value="Simpan Perubahan">
</form>
<a href="read_vendor.php">Kembali ke Daftar Vendor</a>
</body>
</html>
