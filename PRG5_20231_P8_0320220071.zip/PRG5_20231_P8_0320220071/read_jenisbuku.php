<?php
include 'db_connect.php';

$stmt = $pdo->query("SELECT * FROM jenisbuku");
$jenisbuku = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Daftar Jenis Buku</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        h1 {
            color: #008080;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #008080;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            background-color: #008080;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        a:hover {
            background-color: #005555;
        }
    </style>
</head>
<body>
    <h1>Daftar Jenis Buku</h1>
    <a href="create_jenisbuku.php">Tambah Jenis Buku</a>
    <table border="1">
        <tr>
            <th>ID Jenis Buku</th>
            <th>Nama Jenis Buku</th>
            <th>Aksi</th>
        </tr>
        <?php foreach ($jenisbuku as $jenis): ?>
        <tr>
            <td><?=$jenis['id_jenis_buku']?></td>
            <td><?=$jenis['nama_jenis_buku']?></td>
            <td>
                <a href="update_jenisbuku.php?id=<?=$jenis['id_jenis_buku']?>">Edit</a>
                <a href="delete_jenisbuku.php?id=<?=$jenis['id_jenis_buku']?>">Hapus</a>
                <a href="index.php">Kembali ke Halaman Utama</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
