<?php
include 'db_connect.php'; // Hubungkan ke database

// Ambil ID vendor dari parameter URL
$id_vendor = $_GET["id"];

// Query SQL untuk menghapus data di tabel vendor
$sql = "DELETE FROM vendor WHERE id_vendor = :id_vendor";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(":id_vendor", $id_vendor);

if ($stmt->execute()) {
    header("Location: read_vendor.php"); // Redirect ke halaman Read setelah data berhasil dihapus
    exit();
} else {
    echo "Gagal menghapus data.";
}
?>
