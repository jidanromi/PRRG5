<?php
include 'db_connect.php'; // Hubungkan ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_vendor = $_POST["nama_vendor"];
    $alamat_vendor = $_POST["alamat_vendor"];
    $telp_vendor = $_POST["telp_vendor"];
    $email_vendor = $_POST["email_vendor"];

    // Query SQL untuk menambahkan data ke tabel vendor
    $sql = "INSERT INTO vendor (nama_vendor, alamat_vendor, telp_vendor, email_vendor) VALUES (:nama_vendor, :alamat_vendor, :telp_vendor, :email_vendor)";
    $stmt = $pdo->prepare($sql);

    // Bind parameter
    $stmt->bindParam(":nama_vendor", $nama_vendor);
    $stmt->bindParam(":alamat_vendor", $alamat_vendor);
    $stmt->bindParam(":telp_vendor", $telp_vendor);
    $stmt->bindParam(":email_vendor", $email_vendor);

    // Eksekusi statement SQL
    if ($stmt->execute()) {
        header("Location: read_vendor.php"); // Redirect ke halaman Read setelah data berhasil ditambahkan
        exit();
    } else {
        echo "Gagal menambahkan data.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tambah Vendor</title>
</head>
<body>
    <h1>Tambah Vendor</h1>
    <form method="POST" action="">
        <label for="nama_vendor">Nama Vendor:</label>
        <input type="text" id="nama_vendor" name="nama_vendor" required><br><br>

        <label for="alamat_vendor">Alamat Vendor:</label>
        <input type="text" id="alamat_vendor" name="alamat_vendor" required><br><br>

        <label for="telp_vendor">No. Telp Vendor:</label>
        <input type="text" id="telp_vendor" name="telp_vendor" required><br><br>

        <label for="email_vendor">Email Vendor:</label>
        <input type="text" id="email_vendor" name="email_vendor" required><br><br>

        <input type="submit" value="Tambah Vendor">
    </form>
    <a href="read_vendor.php">Kembali ke Daftar Vendor</a>
</body>
</html>
