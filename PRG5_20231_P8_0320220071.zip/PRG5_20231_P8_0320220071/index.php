<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perpustakaan - Home</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>Perpustakaan</h1>
        <nav>
            <ul>
                <li><a href="read_vendor.php">Vendor</a></li>
                <li><a href="read_jenisbuku.php">Jenis Buku</a></li>
                <li><a href="read_buku.php">Buku</a></li>
            </ul>
        </nav>
    </header>

    <section class="section">
        <div class="container">
            <h2>Selamat Datang di Perpustakaan</h2>
            <p>Silakan pilih salah satu menu di atas untuk mengelola data Vendor, Jenis Buku, atau Buku.</p>
        </div>
    </section>

    <footer>
        <div class="container">
            <small>2023 - M Jidan Romi</small>
        </div>
    </footer>
</body>
</html>
