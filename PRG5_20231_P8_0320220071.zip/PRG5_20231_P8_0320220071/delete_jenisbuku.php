<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id_jenis_buku = $_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM jenisbuku WHERE id_jenis_buku = :id_jenis_buku");
    $stmt->bindParam(":id_jenis_buku", $id_jenis_buku);

    if ($stmt->execute()) {
        header("Location: read_jenisbuku.php");
        exit();
    } else {
        echo "Gagal menghapus data jenis buku.";
    }
}
?>
