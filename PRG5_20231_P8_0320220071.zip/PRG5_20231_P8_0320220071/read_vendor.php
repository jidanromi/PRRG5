<?php
include 'db_connect.php'; // Hubungkan ke database

// Query SQL untuk menampilkan data dari tabel vendor
$sql = "SELECT * FROM vendor";
$stmt = $pdo->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Daftar Vendor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #008080;
            padding: 20px;
            text-align: center;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin: 20px auto;
            background-color: white;
            border: 1px solid #ddd;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #008080;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            background-color: #008080;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        a:hover {
            background-color: #005555;
        }

        .container {
            text-align: center;
            margin-top: 20px;
        }

        .back-btn {
            background-color: #008080;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-btn:hover {
            background-color: #005555;
        }
    </style>
</head>
<body>
    <h1>Daftar Vendor</h1>
    <a href="create.php">Tambah Vendor Baru</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID Vendor</th>
                <th>Nama Vendor</th>
                <th>Alamat Vendor</th>
                <th>No. Telp Vendor</th>
                <th>Email Vendor</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><?php echo $row["id_vendor"]; ?></td>
                    <td><?php echo $row["nama_vendor"]; ?></td>
                    <td><?php echo $row["alamat_vendor"]; ?></td>
                    <td><?php echo $row["telp_vendor"]; ?></td>
                    <td><?php echo $row["email_vendor"]; ?></td>
                    <td>
                        <a href="update_vendor.php?id=<?php echo $row["id_vendor"]; ?>">Edit</a>
                        <a href="delete_vendor.php?id=<?php echo $row["id_vendor"]; ?>">Hapus</a>
                        <a href="index.php">Kembali ke Halaman Utama</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
