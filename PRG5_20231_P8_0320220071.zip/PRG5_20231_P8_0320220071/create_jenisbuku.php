<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_jenis_buku = $_POST["nama_jenis_buku"];
    
    $sql = "INSERT INTO jenisbuku (nama_jenis_buku) VALUES (:nama_jenis_buku)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":nama_jenis_buku", $nama_jenis_buku);

    if ($stmt->execute()) {
        header("Location: read_jenisbuku.php");
        exit();
    } else {
        echo "Gagal menambahkan data jenis buku.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tambah Jenis Buku</title>
</head>
<body>
    <h1>Tambah Jenis Buku</h1>
    <form method="POST" action="">
        <label for="nama_jenis_buku">Nama Jenis Buku:</label>
        <input type="text" id="nama_jenis_buku" name="nama_jenis_buku" required><br><br>

        <input type="submit" value="Tambah Jenis Buku">
    </form>
    <a href="read_jenisbuku.php">Kembali ke Daftar Jenis Buku</a>
</body>
</html>
